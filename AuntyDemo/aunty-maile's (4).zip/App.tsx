import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import MenuSection from './components/MenuSection';
import PokeSection from './components/PokeSection';
import CateringSection from './components/CateringSection';
import AboutSection from './components/AboutSection';
import Footer from './components/Footer';
import ImageModal from './components/ImageModal';
import { MenuCategoryData } from './types';
import { fetchMenuData } from './utils/csvLoader';
import { MENU_DATA } from './constants';
import { Loader2 } from 'lucide-react';

type ViewState = 'menu' | 'about';

const App: React.FC = () => {
  const [menuData, setMenuData] = useState<MenuCategoryData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentView, setCurrentView] = useState<ViewState>('menu');
  const [selectedImage, setSelectedImage] = useState<{url: string, title: string} | null>(null);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        const csvData = await fetchMenuData();
        if (csvData && csvData.length > 0) {
          setMenuData(csvData);
        } else {
          console.warn("CSV data empty or failed to load, falling back to constants.");
          setMenuData(MENU_DATA);
        }
      } catch (e) {
        console.error("Error fetching menu data", e);
        setMenuData(MENU_DATA);
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, []);

  const handleViewImage = (url: string, title: string) => {
    setSelectedImage({ url, title });
  };

  const handleCloseModal = () => {
    setSelectedImage(null);
  };

  const handleNavigate = (view: ViewState) => {
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-brand-cream flex items-center justify-center">
        <div className="text-center text-brand-green">
          <Loader2 className="w-10 h-10 animate-spin mx-auto mb-4" />
          <p className="font-serif text-xl">Loading Menu...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-brand-cream text-gray-800 font-sans flex flex-col">
      <Header 
        categories={menuData} 
        currentView={currentView}
        onNavigate={handleNavigate}
      />

      <main className="flex-grow max-w-5xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-16">
        
        {currentView === 'menu' ? (
          <>
            {/* Hero / Intro */}
            <div className="text-center py-12 md:py-20 flex flex-col items-center">
              <div className="mb-8 p-4 rounded-full bg-white/50 shadow-sm border border-white/60">
                 <img src="demo/logo.png" alt="Aunty Maile's Logo" className="w-32 h-auto md:w-48 drop-shadow-sm" onError={(e) => e.currentTarget.style.display = 'none'} />
              </div>
              <h1 className="text-5xl md:text-7xl font-serif text-brand-green mb-4 drop-shadow-sm">
                E Komo Mai
              </h1>
              <p className="text-xl md:text-2xl text-brand-accent font-serif italic">
                "Welcome to our table"
              </p>
              <div className="mt-8 w-24 h-1 bg-brand-accent mx-auto rounded-full opacity-60"></div>
            </div>

            {/* Menu Sections */}
            {menuData.map((category: MenuCategoryData) => {
              if (category.type === 'poke' && category.pokeStyles && category.pokePrices) {
                return (
                  <PokeSection
                    key={category.id}
                    id={category.id}
                    title={category.title}
                    styles={category.pokeStyles}
                    prices={category.pokePrices}
                    footerNote={category.footerNote}
                    onViewImage={handleViewImage}
                  />
                );
              } else if (category.type === 'catering' && category.cateringSubsections) {
                return (
                  <CateringSection
                    key={category.id}
                    id={category.id}
                    title={category.title}
                    subtitle={category.subtitle}
                    subsections={category.cateringSubsections}
                    footerNote={category.footerNote}
                  />
                );
              }
              // Standard Menu Section
              return (
                <MenuSection
                  key={category.id}
                  id={category.id}
                  title={category.title}
                  subtitle={category.subtitle}
                  items={category.items}
                  footerNote={category.footerNote}
                  onViewImage={handleViewImage}
                />
              );
            })}
          </>
        ) : (
          /* About Page View */
          <div className="py-8 animate-in fade-in duration-500">
             <AboutSection
                id="about-page"
                title="About Us"
              />
          </div>
        )}

      </main>

      <Footer />
      
      <ImageModal 
        isOpen={!!selectedImage}
        onClose={handleCloseModal}
        imageUrl={selectedImage?.url}
        title={selectedImage?.title}
      />
    </div>
  );
};

export default App;