import React, { useState } from 'react';
import { MapPin, Clock, Phone, Star, Instagram, Facebook, ImageOff } from 'lucide-react';

interface AboutSectionProps {
  id: string;
  title: string;
}

const FOOD_IMAGES = [
  { src: 'demo/LocoMoco.png', alt: 'Loco Moco' },
  { src: 'demo/GarlicShrimp.png', alt: 'Garlic Shrimp' },
  { src: 'demo/PokeSalad.png', alt: 'Poke Salad' },
  { src: 'demo/MixPlate.png', alt: 'Mix Plate' }
];

const AboutSection: React.FC<AboutSectionProps> = ({ id, title }) => {
  const googleMapsUrl = "https://www.google.com/maps/place/Aunty+Maile's+Hawaiian+Restaurant/@33.8566492,-118.2986993,17z/data=!3m1!4b1!4m6!3m5!1s0x80c2cb194e1fe223:0xdc4537d6473e2178!8m2!3d33.8566492!4d-118.2986993!16s%2Fg%2F11h5lhph1h?entry=ttu";
  const instagramUrl = "https://www.instagram.com/auntymailes/";
  const facebookUrl = "https://www.facebook.com/auntymailes/";
  const yelpUrl = "https://www.yelp.com/biz/aunty-maile-s-hawaiian-restaurant-torrance?osq=Aunty+Mailes";

  return (
    <section id={id} className="py-12 scroll-mt-20 max-w-4xl mx-auto">
      <div className="flex flex-col items-center mb-12 text-center">
        <div className="p-3 bg-brand-green/10 rounded-full mb-4">
          <MapPin className="w-8 h-8 text-brand-green" />
        </div>
        <h2 className="text-3xl md:text-4xl font-serif text-brand-dark font-bold">{title}</h2>
        <p className="text-gray-600 mt-2 font-medium">Serving Aloha Daily</p>
      </div>

      {/* Mission Statement */}
      <div className="text-center mb-16 px-4">
        <h3 className="text-3xl md:text-5xl font-serif italic text-brand-green leading-relaxed mb-8">
          "Our goal is to share the Aloha Spirit and the tastes of Hawaii with our entire ohana."
        </h3>
        <div className="max-w-2xl mx-auto space-y-4 text-gray-600 text-lg leading-relaxed font-light">
          <p>
            Our adventure began more than three decades ago on the Big Island and continues today thanks to the support of wonderful customers like you.
          </p>
          <p>
            Over the years, we have opened locations on the Big Island, in Las Vegas, and in Los Angeles. We love sharing a piece of our island home wherever we go. Mahalo plenty for your support and E Komo Mai (Welcome) to the Aunty Maile's Ohana!
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        {/* Info Card */}
        <div className="bg-white rounded-xl shadow-lg border border-stone-200 p-8 flex flex-col justify-between">
          <div>
            <h3 className="text-xl font-serif font-bold text-brand-green mb-6 border-b border-gray-100 pb-2">Visit Us</h3>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <MapPin className="w-6 h-6 text-brand-accent flex-shrink-0 mt-1" />
                <div>
                  <p className="font-bold text-gray-800">Address</p>
                  <p className="text-gray-600">19106 Normandie Ave #3<br/>Torrance, CA 90502</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Clock className="w-6 h-6 text-brand-accent flex-shrink-0 mt-1" />
                <div>
                  <p className="font-bold text-gray-800">Hours</p>
                  <div className="text-gray-600 mt-1 space-y-1 text-sm">
                    <div className="flex justify-between w-56"><span className="font-medium">Tue - Sat:</span> <span>8:00 AM - 8:00 PM</span></div>
                    <div className="flex justify-between w-56"><span className="font-medium">Sun - Mon:</span> <span>Closed</span></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Contact & Socials Card */}
        <div className="bg-white rounded-xl shadow-lg border border-stone-200 p-8 flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-serif font-bold text-brand-green mb-6 border-b border-gray-100 pb-2">Get in Touch</h3>
              
              <div className="flex items-start gap-4 mb-8">
                <Phone className="w-6 h-6 text-brand-accent flex-shrink-0 mt-1" />
                <div>
                  <p className="font-bold text-gray-800">Contact</p>
                  <p className="text-gray-600 mb-1">(808) 555-0198</p>
                  <p className="text-gray-600">aloha@auntymailes.com</p>
                </div>
              </div>

              <div>
                <p className="font-bold text-gray-800 mb-4 text-sm uppercase tracking-wider text-center md:text-left">Find us on</p>
                <div className="grid grid-cols-2 gap-3">
                   <a 
                     href={facebookUrl} 
                     target="_blank" 
                     rel="noopener noreferrer"
                     className="flex items-center justify-center gap-2 px-3 py-3 bg-[#1877F2]/10 text-[#1877F2] rounded-lg text-sm font-bold hover:bg-[#1877F2] hover:text-white transition-colors"
                   >
                     <Facebook className="w-4 h-4" />
                     Facebook
                   </a>
                   <a 
                     href={instagramUrl} 
                     target="_blank" 
                     rel="noopener noreferrer"
                     className="flex items-center justify-center gap-2 px-3 py-3 bg-[#E1306C]/10 text-[#E1306C] rounded-lg text-sm font-bold hover:bg-[#E1306C] hover:text-white transition-colors"
                   >
                     <Instagram className="w-4 h-4" />
                     Instagram
                   </a>
                   <a 
                     href={yelpUrl} 
                     target="_blank" 
                     rel="noopener noreferrer"
                     className="flex items-center justify-center gap-2 px-3 py-3 bg-[#FF1A1A]/10 text-[#FF1A1A] rounded-lg text-sm font-bold hover:bg-[#FF1A1A] hover:text-white transition-colors"
                   >
                     <Star className="w-4 h-4 fill-current" />
                     Yelp
                   </a>
                   <a 
                     href={googleMapsUrl} 
                     target="_blank" 
                     rel="noopener noreferrer"
                     className="flex items-center justify-center gap-2 px-3 py-3 bg-[#4285F4]/10 text-[#4285F4] rounded-lg text-sm font-bold hover:bg-[#4285F4] hover:text-white transition-colors"
                   >
                     <MapPin className="w-4 h-4" />
                     Google
                   </a>
                </div>
              </div>
            </div>
        </div>
      </div>

      {/* Food Gallery */}
      <div>
        <h3 className="text-2xl font-serif font-bold text-brand-dark text-center mb-8">A Taste of Aloha</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {FOOD_IMAGES.map((img, idx) => (
            <GalleryImage key={idx} src={img.src} alt={img.alt} />
          ))}
        </div>
      </div>
    </section>
  );
};

const GalleryImage: React.FC<{ src: string, alt: string }> = ({ src, alt }) => {
  const [imgError, setImgError] = useState(false);
  
  return (
    <div className="aspect-square rounded-xl overflow-hidden shadow-md border border-stone-200 group relative bg-gray-50">
      {!imgError ? (
        <img 
          src={src} 
          alt={alt} 
          className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
          onError={() => setImgError(true)}
        />
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center text-gray-400 p-2 text-center">
           <ImageOff className="w-8 h-8 mb-2" />
           <span className="text-xs break-all">{src}</span>
        </div>
      )}
    </div>
  );
}

export default AboutSection;