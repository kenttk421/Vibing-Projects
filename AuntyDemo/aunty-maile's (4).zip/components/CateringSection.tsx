import React from 'react';
import { CateringSubsectionData } from '../types';
import { Utensils, AlertCircle } from 'lucide-react';

interface CateringSectionProps {
  id: string;
  title: string;
  subtitle?: string;
  subsections: CateringSubsectionData[];
  footerNote?: string;
}

const CateringSection: React.FC<CateringSectionProps> = ({ id, title, subtitle, subsections, footerNote }) => {
  return (
    <section id={id} className="py-12 scroll-mt-20">
      <div className="flex flex-col items-center mb-10 text-center">
        <div className="p-3 bg-amber-100 rounded-full mb-4">
          <Utensils className="w-8 h-8 text-amber-700" />
        </div>
        <h2 className="text-3xl md:text-4xl font-serif text-brand-dark font-bold">{title}</h2>
        {subtitle && <p className="text-brand-accent mt-2 font-medium text-lg">{subtitle}</p>}
        
        <div className="mt-6 max-w-2xl bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-800 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <div className="text-left space-y-1">
             <p className="font-bold">Important Info:</p>
             <p>• 2 weeks advance notice is preferred, but we will always try to accommodate!</p>
             <p>• We offer a 4% Cash Discount.</p>
             <p>• Pans of food require a 50% deposit.</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg border border-stone-200 overflow-hidden">
        {subsections.map((subsection, index) => (
          <div key={index} className="border-b border-stone-200 last:border-0">
            {/* Subsection Header */}
            <div className="bg-brand-green/5 px-6 py-4 border-l-4 border-brand-green flex justify-between items-center flex-wrap gap-2">
              <h3 className="font-serif font-bold text-xl text-brand-dark">{subsection.title}</h3>
              {/* Dynamic Column Headers based on section type */}
              {!subsection.title.includes('Disposables') && (
                <div className="flex gap-8 text-xs font-bold text-brand-dark uppercase tracking-wider w-full sm:w-auto mt-2 sm:mt-0 justify-end">
                   <span className="w-20 text-right">{subsection.title.includes('Poke') ? '6 LB' : 'Half Pan'}</span>
                   <span className="w-20 text-right">{subsection.title.includes('Poke') ? '12 LB' : 'Full Pan'}</span>
                </div>
              )}
            </div>

            {/* Items */}
            <div className="divide-y divide-gray-100">
              {subsection.items.map((item, idx) => (
                <div key={idx} className="px-6 py-3 flex flex-col sm:flex-row justify-between sm:items-center hover:bg-gray-50 transition-colors">
                  <div className="font-medium text-gray-800 pr-4 mb-1 sm:mb-0">
                    {item.name}
                  </div>
                  
                  {item.unitPrice ? (
                     /* Single Price Item */
                     <div className="font-bold text-gray-600">
                        {item.unitPrice}
                     </div>
                  ) : (
                     /* Dual Price Item */
                     <div className="flex gap-8 justify-between sm:justify-end min-w-[180px]">
                        <span className="w-20 text-right font-medium text-gray-600 bg-gray-50/50 sm:bg-transparent px-2 sm:px-0 rounded">{item.halfPrice || '-'}</span>
                        <span className="w-20 text-right font-bold text-brand-dark bg-brand-green/5 sm:bg-transparent px-2 sm:px-0 rounded">{item.fullPrice || '-'}</span>
                     </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {footerNote && (
        <div className="mt-8 text-center text-xs text-gray-400 italic">
          {footerNote}
        </div>
      )}
    </section>
  );
};

export default CateringSection;
