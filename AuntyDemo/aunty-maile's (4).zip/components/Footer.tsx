import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-green text-brand-light py-16 mt-16 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-2 bg-brand-accent opacity-80"></div>
      
      <div className="max-w-7xl mx-auto px-4 text-center relative z-10">
        <div className="flex justify-center mb-6">
          <div className="bg-white/10 p-6 rounded-full backdrop-blur-sm flex items-center justify-center">
            <img src="demo/logooutline.png" alt="Aunty Maile's" className="h-24 w-auto brightness-0 invert opacity-90" />
          </div>
        </div>
        
        <h2 className="font-script text-4xl mb-4 text-brand-cream tracking-wide">Aunty Maile's</h2>
        <p className="mb-8 opacity-80 max-w-md mx-auto font-light leading-relaxed">
          Serving the best authentic Hawaiian comfort food.<br/>
          Mahalo for supporting local!
        </p>
        
        <div className="border-t border-white/10 pt-8 text-sm opacity-50 flex flex-col items-center gap-2">
          <p>&copy; {new Date().getFullYear()} Aunty Maile's. All rights reserved.</p>
          <p className="text-xs">Prices and availability subject to change.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;