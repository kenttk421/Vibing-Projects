import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Clock, MapPin } from 'lucide-react';
import { MenuCategoryData } from '../types';

interface HeaderProps {
  categories: MenuCategoryData[];
  currentView: 'menu' | 'about';
  onNavigate: (view: 'menu' | 'about') => void;
}

const Header: React.FC<HeaderProps> = ({ categories, currentView, onNavigate }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleCategoryClick = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    setIsMenuOpen(false);

    if (currentView !== 'menu') {
      onNavigate('menu');
      // Allow state update and render to happen before scrolling
      setTimeout(() => {
        const element = document.getElementById(id);
        if (element) {
          const headerOffset = 100;
          const elementPosition = element.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
          window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
          });
        }
      }, 100);
    } else {
      const element = document.getElementById(id);
      if (element) {
        const headerOffset = 100;
        const elementPosition = element.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
        window.scrollTo({
          top: offsetPosition,
          behavior: "smooth"
        });
      }
    }
  };

  const handleNavClick = (view: 'menu' | 'about') => {
    setIsMenuOpen(false);
    onNavigate(view);
  };

  return (
    <>
      {/* Info Bar (Top of Page) */}
      <div className="bg-brand-green text-brand-cream py-2 px-4 shadow-sm relative z-50 border-b border-brand-dark/10">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between md:justify-center items-center gap-x-8 gap-y-2 text-xs md:text-sm font-medium">
            <span className="flex items-center gap-1.5"><Clock className="w-4 h-4 text-brand-accent" /> Tue-Sat 8AM - 8PM</span>
            <span className="flex items-center gap-1.5"><Phone className="w-4 h-4 text-brand-accent" /> (808) 555-0198</span>
            <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4 text-brand-accent" /> Torrance, CA</span>
        </div>
      </div>

      {/* Main Header (Sticky) */}
      <header className={`sticky top-0 left-0 right-0 z-40 transition-all duration-300 ${isScrolled ? 'bg-white shadow-md py-2' : 'bg-brand-cream/95 backdrop-blur-sm py-3'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            
            {/* Logo Area */}
            <div className="flex items-center">
              <button onClick={() => handleNavClick('menu')} className="flex items-center gap-3 group">
                <img 
                  src="demo/logo.png" 
                  alt="Aunty Maile's" 
                  className={`transition-all duration-300 w-auto object-contain ${isScrolled ? 'h-12' : 'h-16 md:h-20'}`}
                />
              </button>
            </div>

            {/* Desktop Nav */}
            <nav className="hidden md:flex space-x-6 lg:space-x-8 items-center">
              <button 
                onClick={() => handleNavClick('menu')}
                className={`font-bold text-sm transition-colors uppercase tracking-wider border-b-2 py-1 ${currentView === 'menu' ? 'text-brand-accent border-brand-accent' : 'text-brand-dark border-transparent hover:text-brand-accent'}`}
              >
                Menu
              </button>
              
              {/* Render categories only if standard menu items exist */}
              {categories.map((cat) => (
                <a
                  key={cat.id}
                  href={`#${cat.id}`}
                  onClick={(e) => handleCategoryClick(e, cat.id)}
                  className="text-brand-dark hover:text-brand-accent font-bold text-sm transition-colors uppercase tracking-wider border-b-2 border-transparent hover:border-brand-accent py-1"
                >
                  {cat.title.replace(/ \(.*\)/, '').replace('Grinds', '')}
                </a>
              ))}

              <button 
                onClick={() => handleNavClick('about')}
                className={`font-bold text-sm transition-colors uppercase tracking-wider border-b-2 py-1 ${currentView === 'about' ? 'text-brand-accent border-brand-accent' : 'text-brand-dark border-transparent hover:text-brand-accent'}`}
              >
                About
              </button>

              <a 
                href="https://auntymaileshawaiian.dine.online/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-brand-accent hover:bg-amber-700 text-white px-5 py-2 rounded-full font-bold text-sm transition-colors shadow-sm ml-2"
              >
                Order Now
              </a>
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 text-brand-green hover:bg-brand-green/10 rounded-full transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Nav Drawer */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 absolute w-full shadow-lg max-h-[80vh] overflow-y-auto">
            <div className="px-4 pt-2 pb-6 space-y-1">
              <button
                onClick={() => handleNavClick('menu')}
                className={`block w-full text-left px-3 py-4 text-base font-bold rounded-md border-b border-gray-100 ${currentView === 'menu' ? 'text-brand-accent bg-amber-50' : 'text-gray-700 hover:text-brand-green'}`}
              >
                FULL MENU
              </button>
              
              {categories.map((cat) => (
                <a
                  key={cat.id}
                  href={`#${cat.id}`}
                  onClick={(e) => handleCategoryClick(e, cat.id)}
                  className="block px-3 py-3 pl-6 text-sm font-medium text-gray-600 hover:text-brand-green hover:bg-green-50 rounded-md border-b border-gray-100"
                >
                  {cat.title}
                </a>
              ))}

              <button
                onClick={() => handleNavClick('about')}
                className={`block w-full text-left px-3 py-4 text-base font-bold rounded-md border-b border-gray-100 last:border-0 ${currentView === 'about' ? 'text-brand-accent bg-amber-50' : 'text-gray-700 hover:text-brand-green'}`}
              >
                ABOUT & REVIEWS
              </button>
              
              <div className="px-3 pt-4 pb-2">
                <a 
                  href="https://auntymaileshawaiian.dine.online/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full text-center bg-brand-accent hover:bg-amber-700 text-white px-5 py-3 rounded-full font-bold text-sm transition-colors shadow-sm"
                >
                  Order Now
                </a>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
};

export default Header;