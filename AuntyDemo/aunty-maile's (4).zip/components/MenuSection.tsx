import React, { useState } from 'react';
import { MenuItemData } from '../types';
import { Leaf, Award, ImageOff } from 'lucide-react';

interface MenuSectionProps {
  id: string;
  title: string;
  subtitle?: string;
  items: MenuItemData[];
  footerNote?: string;
  onViewImage: (url: string, title: string) => void;
}

const MenuSection: React.FC<MenuSectionProps> = ({ id, title, subtitle, items, footerNote, onViewImage }) => {
  return (
    <section id={id} className="py-12 scroll-mt-20">
      <div className="flex flex-col items-center mb-8 text-center">
        <div className="flex items-center gap-2 mb-2">
          <Leaf className="w-6 h-6 text-brand-green" />
          <h2 className="text-3xl md:text-4xl font-serif text-brand-green font-bold">{title}</h2>
          <Leaf className="w-6 h-6 text-brand-green transform scale-x-[-1]" />
        </div>
        {subtitle && (
          <p className="text-gray-600 italic text-lg">{subtitle}</p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {items.map((item, index) => (
          <MenuItem key={index} item={item} onViewImage={onViewImage} />
        ))}
      </div>

      {footerNote && (
        <div className="mt-8 p-4 bg-red-50 border border-red-100 rounded-lg text-center">
          <p className="text-red-700 font-medium text-sm md:text-base">{footerNote}</p>
        </div>
      )}
    </section>
  );
};

const MenuItem: React.FC<{ item: MenuItemData, onViewImage: (url: string, title: string) => void }> = ({ item, onViewImage }) => {
  const [imgError, setImgError] = useState(false);

  return (
    <div className="flex gap-4 bg-white p-4 rounded-lg shadow-sm border border-stone-100 hover:shadow-md transition-all group">
      <div className="flex-grow flex flex-col">
        <div className="flex justify-between items-start mb-1">
          <h3 className="font-bold text-gray-800 text-lg leading-tight">
            {item.name}
          </h3>
          <span className="font-bold text-brand-green whitespace-nowrap ml-2 text-lg">{item.price}</span>
        </div>
        
        <div className="mb-2">
            {item.popular && (
            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider bg-brand-accent text-white">
              <Award className="w-3 h-3 mr-1" />
              Popular
            </span>
          )}
        </div>

        <p className="text-gray-600 text-sm leading-relaxed mb-auto">{item.description}</p>
        
        {item.note && (
          <p className="mt-2 text-xs text-brand-accent font-semibold italic">{item.note}</p>
        )}
      </div>

      {item.image && (
          <div 
            className="flex-shrink-0 w-28 h-28 rounded-md overflow-hidden bg-gray-50 cursor-pointer border border-gray-100 shadow-sm relative"
            onClick={() => !imgError && onViewImage(item.image!, item.name)}
            role="button"
            aria-label={`View photo of ${item.name}`}
          >
            {!imgError ? (
              <img 
                src={item.image} 
                alt={item.name} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                onError={() => setImgError(true)}
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center bg-gray-100 text-gray-400 p-2 text-center">
                <ImageOff className="w-6 h-6 mb-1" />
                <span className="text-[9px] leading-tight break-all">{item.image}</span>
              </div>
            )}
          </div>
      )}
    </div>
  );
};

export default MenuSection;