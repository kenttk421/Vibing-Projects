import React, { useState } from 'react';
import { PokeStyleData, PokePriceData } from '../types';
import { Fish, Camera, ImageOff } from 'lucide-react';

interface PokeSectionProps {
  id: string;
  title: string;
  styles: PokeStyleData[];
  prices: PokePriceData[];
  footerNote?: string;
  onViewImage: (url: string, title: string) => void;
}

const PokeSection: React.FC<PokeSectionProps> = ({ id, title, styles, prices, footerNote, onViewImage }) => {
  return (
    <section id={id} className="py-12 scroll-mt-20 bg-blue-50/50 -mx-4 px-4 sm:-mx-6 sm:px-6 md:rounded-3xl md:mx-0">
      <div className="flex flex-col items-center mb-10 text-center">
        <div className="p-3 bg-blue-100 rounded-full mb-4">
          <Fish className="w-8 h-8 text-blue-600" />
        </div>
        <h2 className="text-3xl md:text-4xl font-serif text-blue-900 font-bold">{title}</h2>
        <p className="text-blue-600 mt-2 font-medium">Fresh Ahi Daily • Customizable</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Left Column: Styles */}
        <div>
          <h3 className="text-xl font-bold text-blue-900 mb-6 border-b border-blue-200 pb-2">1. Choose Your Style</h3>
          <div className="space-y-4">
            {styles.map((style, index) => (
              <PokeStyleItem key={index} style={style} onViewImage={onViewImage} />
            ))}
          </div>
        </div>

        {/* Right Column: Prices */}
        <div className="flex flex-col">
          <h3 className="text-xl font-bold text-blue-900 mb-6 border-b border-blue-200 pb-2">2. Choose Your Size</h3>
          <div className="bg-white rounded-xl shadow-md overflow-hidden flex-grow">
            {prices.map((item, index) => (
              <div key={index} className={`p-6 flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-gray-100 last:border-0 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                <div className="mb-2 sm:mb-0">
                  <span className="text-lg font-bold text-gray-800 block">{item.name}</span>
                  {item.detail && <span className="text-xs text-gray-500 block mt-1 max-w-xs">{item.detail}</span>}
                </div>
                <span className="text-xl font-bold text-brand-green bg-green-50 px-3 py-1 rounded-lg border border-green-100">
                  {item.price}
                </span>
              </div>
            ))}
          </div>
          
          {/* Upgrade Badge */}
          <div className="mt-6 bg-brand-accent/10 border border-brand-accent/20 rounded-lg p-4 text-center">
             <p className="text-brand-accent font-bold">Pork Fried Rice Upgrade Available +$3.00</p>
          </div>
        </div>
      </div>

      {footerNote && (
        <div className="mt-8 text-center text-xs text-gray-400 max-w-2xl mx-auto italic">
          {footerNote}
        </div>
      )}
    </section>
  );
};

const PokeStyleItem: React.FC<{ style: PokeStyleData, onViewImage: (url: string, title: string) => void }> = ({ style, onViewImage }) => {
  const [imgError, setImgError] = useState(false);

  return (
    <div className="flex gap-4 p-3 bg-white rounded-lg shadow-sm hover:shadow-md transition-all border border-blue-100 group">
      {style.image && (
          <div 
              className="w-16 h-16 rounded-md bg-blue-50 flex-shrink-0 overflow-hidden cursor-pointer relative"
              onClick={() => !imgError && onViewImage(style.image!, style.name)}
          >
              {!imgError ? (
                <img 
                    src={style.image} 
                    alt={style.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                    onError={() => setImgError(true)}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gray-100 text-gray-400">
                   <ImageOff className="w-6 h-6" />
                </div>
              )}
          </div>
      )}
      <div className="flex-grow">
          <h4 className="font-bold text-lg text-gray-800 flex items-center gap-2">
              {style.name}
              {!style.image && style.image !== undefined && (
                  <Camera className="w-4 h-4 text-blue-300" />
              )}
          </h4>
          <p className="text-gray-600 text-sm mt-1 leading-snug">{style.description}</p>
      </div>
    </div>
  );
};

export default PokeSection;