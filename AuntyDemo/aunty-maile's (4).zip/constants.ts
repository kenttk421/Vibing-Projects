import { MenuCategoryData } from './types';

export const MENU_DATA: MenuCategoryData[] = [
  {
    id: 'breakfast',
    title: 'Breakfast Grinds',
    subtitle: '(No Mac Salad)',
    type: 'standard',
    items: [
      {
        name: 'Loco Moco',
        description: '10oz hamburger patty grilled to perfection, two eggs—your style, topped with our rich homemade brown gravy over rice.',
        price: '$16.95',
        popular: true,
        image: 'demo/LocoMoco.png'
      },
      {
        name: 'Roast Pork Loco Moco',
        description: 'Tender, juicy roast pork two eggs—your style and topped with our rich homemade brown gravy over rice.',
        price: '$17.95',
        image: 'demo/RoastPorkLocoMoco.png'
      },
      {
        name: 'Chicken Katsu Loco Moco',
        description: 'Tender, crispy and golden brown chicken katsu topped with two eggs—your style and topped with our rich homemade brown gravy over rice.',
        price: '$16.95',
        image: 'demo/ChickenKatsuLocoMoco.png'
      },
      {
        name: 'Spam or Portuguese Sausage and Eggs',
        description: 'Two eggs—your style served with 2 scoops rice.',
        price: '$12.95',
        image: 'demo/SpamandEggs.png'
      },
      {
        name: 'Local Deluxe',
        description: '2 slices of Spam and 3 slices Portuguese Sausage topped with two eggs—your style served with rice.',
        price: '$13.95',
        image: 'demo/LocalDeluxe.png'
      }
    ]
  },
  {
    id: 'local-favorites',
    title: 'Local Favorites',
    subtitle: '(served w/ rice and mac salad)',
    type: 'standard',
    items: [
      {
        name: 'Chicken Katsu',
        description: 'Boneless chicken thighs fried till golden brown and served with katsu sauce. *OR with our homemade rich brown gravy.',
        price: '$16.95',
        popular: true,
        image: 'demo/ChickenKatsu.png'
      },
      {
        name: 'Beef Teriyaki Steak',
        description: 'Thinly sliced bottom sirloin marinated in our special Hawaiian sauce and grilled to perfection. (Cooked pink in the middle unless ordered otherwise)',
        price: '$20.95',
        image: 'demo/BeefTeriyakiSteak.png'
      },
      {
        name: 'Furikake Chicken',
        description: 'Deep fried boneless chicken thighs tossed in our savory homemade furikake glaze.',
        price: '$17.95',
        image: 'demo/FurikakeChicken.png'
      },
      {
        name: 'Teriyaki Chicken',
        description: 'Boneless, skinless chicken thighs marinated in our sweet and savory sauce grilled to perfection.',
        price: '$16.95',
        image: 'demo/TeriyakiChicken.png'
      },
      {
        name: 'Hamburger Steak',
        description: 'Homemade juicy 10oz patty, grilled to perfection, topped with grilled mushrooms and onions, smothered with our rich homemade brown gravy.',
        price: '$16.95',
        image: 'demo/HamburgerSteak.png'
      },
      {
        name: 'Garlic Shrimp',
        description: 'Jumbo shrimp, cooked in garlic butter, served North Shore style (shell-on ez-peel).',
        price: '$18.95',
        popular: true,
        image: 'demo/GarlicShrimp.png'
      },
      {
        name: 'Kalbi Short Ribs (USDA Choice)',
        description: 'Tender short ribs, marinated in our homemade sauce and grilled to perfection.',
        price: '$22.95',
        image: 'demo/KalbiShortRibs.png'
      },
      {
        name: 'Hawaiian Style Roast Pork',
        description: 'Made local style with Hawaiian salt, cracked black pepper, thinly sliced and topped with our rich homemade brown gravy.',
        price: '$17.95',
        image: 'demo/HawaiianStyleRoastPork.png'
      },
      {
        name: 'Chopped Steak and Onions',
        description: 'Thinly sliced tender steak stir-fried with onions and bell peppers, finished with our special stir-fry sauce.',
        price: '$21.95',
        image: 'demo/ChoppedSteakAndOnions.png'
      },
      {
        name: 'Korean Chicken',
        description: 'Golden fried drumettes and wings tossed in our onolicious Korean sauce.',
        price: '$16.95',
        image: 'demo/KoreanChicken.png'
      },
      {
        name: 'Kalua Pig and Cabbage',
        description: 'Kalua pork slow cooked till tender and juicy served with steamed cabbage and a touch of Hawaiian salt.',
        price: '$16.95',
        image: 'demo/KaluaPigAndCabbage.png'
      },
      {
        name: 'Mix Plate',
        description: 'Select *TWO Local Favorite Items. Additional $4.00 for Beef and/or Shrimp Item.',
        price: '$18.95 - $22.95',
        note: 'Additional charge for premium items applies.',
        image: 'demo/MixPlate.png'
      }
    ],
    footerNote: "**Pork Fried Rice Upgrade $3.00**"
  },
  {
    id: 'other-kine',
    title: 'Other Kine Grinds',
    type: 'standard',
    items: [
      {
        name: 'Oxtail Soup',
        description: 'Fresh tender beef oxtail simmered in fresh ginger. Served with rice and mac salad.',
        price: '$21.95',
        image: 'demo/OxtailSoup.png'
      },
      {
        name: 'Hawaiian Style Saimin',
        description: 'With char siu, eggs, fish cakes, dumplings, and green onions.',
        price: '$12.95',
        image: 'demo/HawaiianStyleSaimin.png'
      },
      {
        name: 'Poke Salad',
        description: 'Your choice of LARGE Poke served with a LARGE salad (Romaine, Hawaiian sweet potatoes, tomatoes, cucumbers, oranges, won tons) homemade creamy sesame dressing on the side.',
        price: '$24.95',
        image: 'demo/PokeSalad.png'
      },
      {
        name: 'Teriyaki Chicken Salad',
        description: 'Tender broiled boneless teriyaki chicken, served with a LARGE salad (Romaine, Hawaiian sweet potatoes, tomatoes, cucumbers, oranges, won tons) homemade creamy sesame dressing on the side. (not served with teri sauce)',
        price: '$17.95',
        image: 'demo/TeriyakiChickenSalad.png'
      },
      {
        name: 'Chicken Katsu Salad',
        description: 'Crispy, golden brown chicken katsu, served with a LARGE salad (Romaine, sweet potatoes, tomatoes, cucumbers, oranges, won tons) homemade creamy sesame dressing on the side. (not served with katsu sauce)',
        price: '$17.95',
        image: 'demo/ChickenKatsuSalad.png'
      }
    ],
    footerNote: "Mac salad can be substituted with a small Green Salad or Small Sautéed Fresh Vegetables (carrots/onions/cabbage/bell peppers)."
  },
  {
    id: 'poke',
    title: 'Hawaiian Style Ahi Poke',
    type: 'poke',
    items: [],
    pokeStyles: [
      {
        name: 'Hawaiian Style (no soy sauce)',
        description: 'Mixed with ogo, inamona (kukui nuts), onions, green onions and Hawaiian salt',
        image: 'demo/HawaiianStylePoke.png'
      },
      {
        name: 'Shoyu Style (with soy sauce)',
        description: 'Yellow onions, green onions, black pepper, chili pepper and tossed with our special Poke sauce.',
        image: 'demo/ShoyuStylePoke.png'
      },
      {
        name: 'Sesame Style (with soy sauce)',
        description: 'Yellow onions, green onions, black pepper, chili pepper, sesame oil, sesame seeds and tossed with our special Poke sauce.',
        image: 'demo/SesameStylePoke.png'
      },
      {
        name: 'Furikake Style (with soy sauce)',
        description: 'Yellow onions, green onions, black pepper, furikake seasoning tossed with our special Poke sauce.',
        image: 'demo/FurikakeStylePoke.png'
      },
      {
        name: 'Avo Style (with soy sauce)',
        description: 'Yellow onions, green onions, black pepper, chili pepper, sesame oil, avocado all tossed with our special Poke sauce and topped with spicy Sriracha mayo. ***Subject to availability***',
        image: 'demo/AvoStylePoke.png'
      }
    ],
    pokePrices: [
      { name: 'Poke Only: Large', price: '$21.95' },
      { name: 'Poke Only: Small', price: '$12.95' },
      { name: 'Poke Bowl', price: '$15.95', detail: 'Your choice of SMALL Poke served with steamed rice and mac salad.' },
      { name: 'Poke Plate', price: '$24.95', detail: 'Your choice of LARGE Poke served with steamed rice and mac salad.' }
    ],
    footerNote: "** Consuming raw or undercooked meat, poultry, seafood, shell stock or eggs may increase your risk of food borne illness."
  },
  {
    id: 'catering',
    title: 'Catering Menu',
    type: 'catering',
    subtitle: 'Aunty Maile\'s Catering Menu',
    items: [],
    footerNote: 'Updated 11/14/2025. PANS OF FOOD REQUIRE A 50% DEPOSIT. We offer 4% Cash Discount.',
    cateringSubsections: [
      {
        title: 'Rice',
        items: [
          { name: 'Rice', halfPrice: '$25', fullPrice: '$45' },
          { name: 'Char Siu Pork Fried Rice', halfPrice: '$55', fullPrice: '$100' },
          { name: 'Veggie Fried Rice', halfPrice: '$55', fullPrice: '$100' }
        ]
      },
      {
        title: 'Veggies / Salad / Sides',
        items: [
          { name: 'Musubi (20 / 45)', halfPrice: '$65', fullPrice: '$135' },
          { name: 'Toss Salad', halfPrice: '$35', fullPrice: '$60' },
          { name: 'Sauteed Veggies', halfPrice: '$55', fullPrice: '$90' },
          { name: 'Macaroni Salad', halfPrice: '$60', fullPrice: '$105' },
          { name: 'Lomi Lomi Salmon', halfPrice: '$100', fullPrice: '$195' }
        ]
      },
      {
        title: 'Entrees',
        items: [
          { name: 'Kalua Pork w/ Cabbage', halfPrice: '$95', fullPrice: '$180' },
          { name: 'Chicken Katsu', halfPrice: '$95', fullPrice: '$180' },
          { name: 'Korean Chicken', halfPrice: '$95', fullPrice: '$180' },
          { name: 'Furikake Chicken', halfPrice: '$95', fullPrice: '$180' },
          { name: 'Teriyaki Chicken', halfPrice: '$95', fullPrice: '$180' },
          { name: 'Hamburger Steak', halfPrice: '$95', fullPrice: '$180' },
          { name: 'Kalua Pork (no cabbage)', halfPrice: '$110', fullPrice: '$210' },
          { name: 'Roast Pork w/ Gravy', halfPrice: '$110', fullPrice: '$210' },
          { name: 'Furikake Shrimp', halfPrice: '$120', fullPrice: '$225' },
          { name: 'Garlic Shrimp', halfPrice: '$125', fullPrice: '$235' },
          { name: 'Beef Teriyaki', halfPrice: '$155', fullPrice: '$295' },
          { name: 'Chopsteak & Onions', halfPrice: '$155', fullPrice: '$295' },
          { name: 'Kalbi', halfPrice: '$195', fullPrice: '$350' }
        ]
      },
      {
        title: 'Poke (6 lb / 12 lb)',
        items: [
          { name: 'Shoyu', halfPrice: '$118', fullPrice: '$237', description: '6 lb / 12 lb' },
          { name: 'Sesame', halfPrice: '$118', fullPrice: '$237', description: '6 lb / 12 lb' },
          { name: 'Furikake', halfPrice: '$118', fullPrice: '$237', description: '6 lb / 12 lb' },
          { name: 'Hawaiian (no sauce / contains nuts)', halfPrice: '$118', fullPrice: '$237', description: '6 lb / 12 lb' }
        ]
      },
      {
        title: 'Disposables',
        items: [
          { name: 'Paper Plates (each)', unitPrice: '$0.10' },
          { name: 'Napkin Bundle (150 ct)', unitPrice: '$5.00' },
          { name: 'Cutlery Kit (each / case 250)', unitPrice: '$0.25 / $50' },
          { name: 'Chopsticks (each)', unitPrice: '$0.15' },
          { name: 'To-Go Cont. (each)', unitPrice: '$0.50' }
        ]
      }
    ]
  }
];