
export interface MenuItemData {
  name: string;
  description: string;
  price: string;
  note?: string;
  popular?: boolean;
  image?: string;
}

export interface PokeStyleData {
  name: string;
  description: string;
  image?: string;
}

export interface PokePriceData {
  name: string;
  price: string;
  detail?: string;
}

export interface CateringItemData {
  name: string;
  halfPrice?: string;
  fullPrice?: string;
  unitPrice?: string;
  description?: string;
}

export interface CateringSubsectionData {
  title: string;
  items: CateringItemData[];
  note?: string;
}

export interface MenuCategoryData {
  id: string;
  title: string;
  subtitle?: string;
  items: MenuItemData[];
  type: 'standard' | 'poke' | 'catering' | 'about'; 
  pokeStyles?: PokeStyleData[];
  pokePrices?: PokePriceData[];
  cateringSubsections?: CateringSubsectionData[];
  footerNote?: string;
}
