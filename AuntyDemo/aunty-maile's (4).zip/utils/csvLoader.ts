import { MenuCategoryData, MenuItemData, PokeStyleData, PokePriceData, CateringSubsectionData, CateringItemData } from '../types';

// Helper to handle CSV line splitting including quoted fields
const splitCSVLine = (line: string): string[] => {
  const matches = line.match(/(".*?"|[^",\s]+)(?=\s*,|\s*$)/g) || [];
  const result: string[] = [];
  
  let current = '';
  let inQuote = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      inQuote = !inQuote;
    } else if (char === ',' && !inQuote) {
      result.push(current.trim().replace(/^"|"$/g, '').replace(/""/g, '"'));
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim().replace(/^"|"$/g, '').replace(/""/g, '"'));
  
  return result;
};

export const fetchMenuData = async (): Promise<MenuCategoryData[]> => {
  try {
    // Changed from '/menu.csv' to 'menu.csv' for relative path resolution
    const response = await fetch('menu.csv');
    const text = await response.text();
    
    // Split by new line, remove header row (index 0)
    const rows = text.split('\n').filter(row => row.trim() !== '');
    const dataRows = rows.slice(1);
    
    const categoriesMap = new Map<string, MenuCategoryData>();

    dataRows.forEach(row => {
      const columns = splitCSVLine(row);
      // Map columns based on CSV structure
      // 0: CategoryID, 1: CategoryTitle, 2: CategorySubtitle, 3: CategoryType, 
      // 4: SubCategory, 5: ItemName, 6: ItemDescription, 
      // 7: Price, 8: PriceHalf, 9: PriceFull, 
      // 10: Popular, 11: Image, 12: ItemNote, 13: FooterNote

      const [
        catId, catTitle, catSubtitle, catType, 
        subCat, itemName, itemDesc, 
        price, priceHalf, priceFull, 
        popular, image, itemNote, footerNote
      ] = columns;

      if (!catId) return;

      // Initialize category if not exists
      if (!categoriesMap.has(catId)) {
        categoriesMap.set(catId, {
          id: catId,
          title: catTitle,
          subtitle: catSubtitle,
          type: catType as 'standard' | 'poke' | 'catering',
          items: [],
          pokeStyles: [],
          pokePrices: [],
          cateringSubsections: [],
          footerNote: footerNote
        });
      }

      const category = categoriesMap.get(catId)!;

      // Ensure footer note is set (if multiple rows have it, last one wins, usually they are same)
      if (footerNote) category.footerNote = footerNote;

      if (category.type === 'standard') {
        category.items.push({
          name: itemName,
          description: itemDesc,
          price: price,
          popular: popular?.toLowerCase() === 'true',
          image: image,
          note: itemNote
        });
      } else if (category.type === 'poke') {
        if (subCat === 'Styles') {
          category.pokeStyles?.push({
            name: itemName,
            description: itemDesc,
            image: image
          });
        } else if (subCat === 'Prices') {
          category.pokePrices?.push({
            name: itemName,
            price: price,
            detail: itemDesc
          });
        }
      } else if (category.type === 'catering') {
        // Find or create subsection
        let subsection = category.cateringSubsections?.find(s => s.title === subCat);
        if (!subsection) {
          subsection = { title: subCat, items: [] };
          category.cateringSubsections?.push(subsection);
        }

        const cateringItem: CateringItemData = {
          name: itemName,
          description: itemDesc
        };

        if (priceHalf || priceFull) {
          cateringItem.halfPrice = priceHalf;
          cateringItem.fullPrice = priceFull;
        } else {
          cateringItem.unitPrice = price;
        }

        subsection.items.push(cateringItem);
      }
    });

    return Array.from(categoriesMap.values());

  } catch (error) {
    console.error("Error loading menu CSV:", error);
    return [];
  }
};